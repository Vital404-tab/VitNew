CREATE TABLE Manufacturer(
	ID serial primary key,
	Name varchar(100) NOT NULL,
	StartDate date NULL
);

CREATE TABLE Product(
	ID serial primary key,
	Title varchar(100) NOT NULL,
	Cost numeric NOT NULL,
	Description varchar(2000) NULL,
	MainImagePath varchar(1000) NULL,
	IsActive bool NOT NULL,
	ManufacturerID int references Manufacturer(ID)
);

CREATE TABLE ProductPhoto(
	ID serial primary key,
	ProductID int references Product(ID) not null,
	PhotoPath varchar(1000) NOT NULL
);

CREATE TABLE AttachedProduct(
	ID serial primary key,
	MainProductID int references Product(ID) not null,
	AttachedProductID int references Product(ID) not null
);

CREATE TABLE ProductSale(
	ID serial primary key,
	SaleDate timestamp with time zone NOT NULL,
	ProductID int references Product(ID) NOT NULL,
	Quantity int NOT NULL
);