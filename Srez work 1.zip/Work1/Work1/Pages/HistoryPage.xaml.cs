﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Controls.Primitives;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using Work1.Class;
using Work1.DBContex;

namespace Work1.Pages
{
   
    public partial class HistoryPage : Page
    {

        ApplicationContext db = new ApplicationContext();

        public HistoryPage(ProductListClass selectedItem)
        {
            InitializeComponent();
            FilterBox.ItemsSource = db.product.ToList();
            FilterBox.SelectedIndex = selectedItem.id - 1;
        }

        private void BackButton_Click(object sender, RoutedEventArgs e)
        {
            NavigationService.GoBack();
        }

        private void FilterBox_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            var selected = FilterBox.SelectedItem as Product;

            List<ProductListClass> productListClasses = new List<ProductListClass>();

            if (db.productsale.Where(x => x.productid == selected.id).Count() > 0)
            {
                foreach (var i in db.productsale.Where(x => x.productid == selected.id).ToList())
                {
                    ProductListClass pr = new ProductListClass();
                    pr.title = selected.title;
                    pr.cost = selected.cost;
                    pr.saledate = i.saledate;
                    pr.quantity = i.quantity;
                    pr.mainimagepath = $@"{Directory.GetParent(Environment.CurrentDirectory)}\products_photo\{selected.mainimagepath}" ;
                    productListClasses.Add(pr);
                }
                ProductList.ItemsSource = productListClasses;
            }
            else MessageBox.Show($"История продаж у товара - {selected.title} не найдена");
        }
    }
}
