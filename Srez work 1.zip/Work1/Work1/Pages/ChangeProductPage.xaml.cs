﻿using Microsoft.Win32;
using System.Diagnostics.Eventing.Reader;
using System.IO;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using Work1.Class;
using Work1.DBContex;

namespace Work1.Pages
{
    /// <summary>
    /// Логика взаимодействия для ChangeProductPage.xaml
    /// </summary>
    public partial class ChangeProductPage : Page
    {

        ApplicationContext db = new ApplicationContext();
        List<Product> dopProduct;
        ProductListClass selectedProduct;
        Image photoimage = new Image();
        string photopath;
        string file;

        public ChangeProductPage(ProductListClass selectedProduct)
        {
            InitializeComponent();
            this.selectedProduct = selectedProduct;
            ManufacturerBox.ItemsSource = db.manufacturer.ToList();
            foreach (var i in db.manufacturer.ToList())
                if (i.name == selectedProduct.manufacturerid)
                    ManufacturerBox.SelectedIndex = i.id - 1;
            IDBlock.Text = selectedProduct.id.ToString();
            TitleBlock.Text = selectedProduct.title;
            CostBlock.Text = selectedProduct.cost.ToString();
            if (selectedProduct.description != null) DescriptionBlock.Text = selectedProduct.description;
            if(selectedProduct.mainimagepath != null)
            {
                photoimage.Width = 150;
                photoimage.Height = 110;
                photoimage.Source = new BitmapImage(new Uri(selectedProduct.mainimagepath));
                MainImagePanel.Children.Add(photoimage);
            }
            if (selectedProduct.isactive != "Активность: нет") ActiveBox.IsChecked = true;
            LoadData();
        }

        public void LoadData()
        {
            List<ProductListClass> productLists = new List<ProductListClass>();
            dopProduct = new List<Product>();
            List<Product> products = db.product.ToList();
            foreach (var j in db.attachedproduct.ToList())
                if (j.mainproductid == selectedProduct.id)
                    foreach (var i in products)
                        if (i.id == j.attachedproductid)
                            dopProduct.Add(i);

            if (dopProduct.Count > 0)
            {
                foreach (var i in dopProduct)
                    products = products.Where(x => x.id != i.id).ToList();
                foreach (var i in dopProduct)
                {
                    ProductListClass productListClass = new ProductListClass();
                    productListClass.id = i.id;
                    productListClass.title = i.title + " за " + i.cost.ToString();
                    if (i.mainimagepath != null) productListClass.mainimagepath = $@"{Directory.GetParent(Environment.CurrentDirectory)}\products_photo\{i.mainimagepath}";
                    productLists.Add(productListClass);
                }
            }
            DopList.ItemsSource = productLists;

            productLists = new List<ProductListClass>();
            foreach (var i in products)
            {
                ProductListClass productListClass = new ProductListClass();
                if (i.isactive != false)
                {
                    productListClass.id = i.id;
                    productListClass.title = i.title;
                    if (i.mainimagepath != null) productListClass.mainimagepath = $@"{Directory.GetParent(Environment.CurrentDirectory)}\products_photo\{i.mainimagepath}";
                    productListClass.cost = i.cost;
                    productLists.Add(productListClass);
                }
            }
            DopProductList.ItemsSource = productLists;
        }

        private void ChangeProductButton_Click(object sender, RoutedEventArgs e)
        {
            if (String.IsNullOrWhiteSpace(TitleBlock.Text) || String.IsNullOrWhiteSpace(CostBlock.Text))
                MessageBox.Show("Заполните все поля");
            else if (ManufacturerBox.SelectedIndex == -1)
                MessageBox.Show("Выберите производителя");
            else if (CostBlock.Text.Equals('-') || CostBlock.Text.Equals(','))
                MessageBox.Show("Неправильный формат цены");
            else
            {
                try
                {
                    string nameMauf = (ManufacturerBox.SelectedItem as Manufacturer).name;
                    var uRow = db.product.Where(x => x.id == selectedProduct.id).FirstOrDefault();
                    uRow.title = TitleBlock.Text;
                    uRow.cost = Convert.ToDecimal(CostBlock.Text);
                    uRow.description = DescriptionBlock.Text;
                    if (photopath != null) uRow.mainimagepath = $"Товары школы\\{photopath}";
                    if (ActiveBox.IsChecked == true) uRow.isactive = true;
                    else uRow.isactive = false;
                    foreach (var i in db.manufacturer.ToList())
                        if (i.name == nameMauf)
                        {
                            uRow.manufacturerid = i.id;
                            break;
                        }
                    db.SaveChanges();

                    List<Product> pr = db.product.ToList();
                    bool exist = false;
                    if (photopath != null)
                    {
                        foreach (var p in pr)
                            if (p.mainimagepath.Contains(photopath))
                                exist = true;
                    }
                    else exist = true;

                    if (exist == false)
                    {
                        string newLocation = " ";
                        string folderLocation = $@"{Directory.GetParent(Environment.CurrentDirectory)}\products_photo\Товары школы";
                        newLocation = folderLocation + "\\" + photopath;
                        File.Copy(file, newLocation, true);
                    }
                    MessageBox.Show("Вы изменили информацию о товаре");
                }
                catch
                {
                    MessageBox.Show("Неправильный формат цены");
                }
            }
        }

        private void BackButton_Click(object sender, RoutedEventArgs e)
        {
            NavigationService.Navigate(new MainPage());
        }

        private void MainImagePanel_MouseDown(object sender, MouseButtonEventArgs e)
        {
            MainImagePanel.Children.Clear();
            OpenFileDialog openFileDialog = new OpenFileDialog();
            openFileDialog.InitialDirectory = "C:\\";
            openFileDialog.Filter = "image files (*.png)|*.png;*.jpg|All files (*.*)|*.*";
            if (openFileDialog.ShowDialog().Value)
            {
                file = openFileDialog.FileName;
                var longMB = file.Length / 1024;
                if (longMB <= 2)
                {
                    photoimage.Width = 150;
                    photoimage.Height = 150;
                    photoimage.Source = new BitmapImage(new Uri(file));
                    MainImagePanel.Children.Add(photoimage);
                    photopath = openFileDialog.SafeFileName;
                }
                else MessageBox.Show("Файл слишком большой");
            }
        }

        private void DeleteDopProductButton_Click(object sender, RoutedEventArgs e)
        {
            var selectedItem = DopList.SelectedItem as ProductListClass;
            if (selectedItem != null)
            {
                var dop = db.attachedproduct.Where(x => x.attachedproductid == selectedItem.id && x.mainproductid == selectedProduct.id).ToList();
                foreach (var i in dop)
                {
                    db.attachedproduct.Remove(i);
                    db.SaveChanges();
                }
                LoadData();
            }
            else MessageBox.Show("Чтобы удалить доп. товар, нажмите на элемент");
        }

        private void AddDopProductButton_Click(object sender, RoutedEventArgs e)
        {
            var selectedItem = DopProductList.SelectedItem as ProductListClass;
            if (selectedItem != null)
            {
                AttachedProduct attachedProduct = new AttachedProduct();
                attachedProduct.mainproductid = selectedProduct.id;
                attachedProduct.attachedproductid = selectedItem.id;
                db.attachedproduct.Add(attachedProduct);
                db.SaveChanges();
                LoadData();
            }
            else MessageBox.Show("Чтобы добавить доп. товар, нажмите на элемент");
        }
    }
}
