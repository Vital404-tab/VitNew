﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using Work1.Class;
using Work1.DBContex;

namespace Work1.Pages
{
    /// <summary>
    /// Логика взаимодействия для MainPage.xaml
    /// </summary>
    public partial class MainPage : Page
    {

        ApplicationContext db = new ApplicationContext();
        List<ProductListClass> productLists = new List<ProductListClass>();

        public MainPage()
        {
            InitializeComponent();
        }

        private void Page_Loaded(object sender, RoutedEventArgs e)
        {
            LoadData();
            List<String> nameManuf = new List<String>();
            List<Manufacturer> Manuf = db.manufacturer.ToList();
            nameManuf.Add("Все элементы");
            foreach (var i in Manuf)
                nameManuf.Add(i.name);
            FilterBox.ItemsSource = nameManuf;
        }

        public void LoadData()
        {
            ProductList.ItemsSource = null;           
            productLists = new List<ProductListClass>();
            List<Product> products = db.product.ToList();
            List<Manufacturer> manufacturers = db.manufacturer.ToList();

            foreach(var i in products)
            {
                ProductListClass productListClass = new ProductListClass();
                int count = db.attachedproduct.Where(x=>x.mainproductid == i.id).Count();
                foreach (var j in manufacturers)
                {
                    if(i.manufacturerid == j.id)
                    {
                        productListClass.id = i.id;
                        productListClass.title = i.title;
                        if (count > 0)
                            productListClass.countDopProduct = $"({count})";
                        else productListClass.countDopProduct = "";
                        productListClass.description = i.description;
                        if (i.mainimagepath != null) productListClass.mainimagepath = $@"{Directory.GetParent(Environment.CurrentDirectory)}\products_photo\{i.mainimagepath}";
                        productListClass.cost = i.cost;
                        if (i.isactive == true)
                        {
                            productListClass.isactive = "";
                            productListClass.colorBack = "White";
                        }
                        else
                        {
                            productListClass.isactive = "Активность: нет";
                            productListClass.colorBack = "LightGray";
                        }
                            productListClass.manufacturerid = j.name;
                        productLists.Add(productListClass);
                    }
                }
            }
            ProductList.ItemsSource = productLists;
            OldQuantity.Text = db.product.Count().ToString();
            NewQuantity.Text = products.Count.ToString();
        }

        public List<ProductListClass> filterAll(string costSort)
        {
            if (costSort == "По возрастанию")
                return productLists = productLists.OrderBy(x => x.cost).ToList();
            else if (costSort == "По убыванию")
                return productLists = productLists.OrderByDescending(x => x.cost).ToList();
            else return productLists;
        }

        public void Filter()
        {
            ProductList.ItemsSource = "";
            string manuf = "";
            string costSort = "";

            if (FilterBox.SelectedItem == null)
                manuf = null;
            else
                manuf = FilterBox.SelectedItem.ToString();

            if (SortBox.SelectedItem == null)
                costSort = null;
            else
                costSort = ((ComboBoxItem)SortBox.SelectedValue).Content.ToString();

            if (manuf != null)
            {
                if (manuf == "Все элементы")
                    productLists = filterAll(costSort);
                else
                {
                    if (costSort == "По возрастанию")
                        productLists = productLists.Where(x=>x.manufacturerid == manuf).OrderBy(x => x.cost).ToList();
                    else if (costSort == "По убыванию")
                        productLists = productLists.Where(x => x.manufacturerid == manuf).OrderByDescending(x => x.cost).ToList();
                    else productLists = productLists.Where(x => x.manufacturerid == manuf).ToList();
                }

                if (!string.IsNullOrWhiteSpace(SearchBox.Text))
                    Search();
                NewQuantity.Text = productLists.Count.ToString();

                if (productLists.Count == 0 || productLists == null)
                    ProductList.ItemsSource = "";
                else ProductList.ItemsSource = productLists;
            }
            else
            {
                productLists = filterAll(costSort);
                if (!string.IsNullOrWhiteSpace(SearchBox.Text))
                    Search();
                NewQuantity.Text = productLists.Count.ToString();
                if (productLists.Count == 0 || productLists == null)
                    ProductList.ItemsSource = "";
                else ProductList.ItemsSource = productLists;
            }
        }

        public void Search()
        {
            int count = productLists.Where(x => x.description != null).Count();
            if (count > 0)
            {
                if(productLists.Equals(SearchBox.Text))
                    productLists = productLists.Where(c => c.title.ToLower().Contains(SearchBox.Text.ToLower()) || c.description.ToLower().Contains(SearchBox.Text)).ToList();
                else productLists = productLists.Where(c => c.title.ToLower().Contains(SearchBox.Text.ToLower())).ToList();
            }
            else
                productLists = productLists.Where(c => c.title.ToLower().Contains(SearchBox.Text.ToLower())).ToList();
        }

        private void SearchBox_TextChanged(object sender, TextChangedEventArgs e)
        {
            if (!string.IsNullOrWhiteSpace(SearchBox.Text))
                Filter();
            else
            {
                LoadData();
                Filter();
            }
        }

        private void FilterBox_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            LoadData();
            Filter();
        }

        private void SortBox_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            LoadData();
            Filter();
        }

        private void DeleteButton_Click(object sender, RoutedEventArgs e)
        {
            var selectedItem = ProductList.SelectedItem as ProductListClass;
            if (selectedItem != null)
            {
                if (MessageBox.Show($"Вы хотите удалить этот товар - '{(ProductList.SelectedItem as ProductListClass).title}'",
                "Предупреждение", MessageBoxButton.YesNo, MessageBoxImage.Question) == MessageBoxResult.Yes)
                {
                    var history = db.productsale.Where(x=>x.productid == selectedItem.id).ToList();
                    if (history.Count == 0)
                    {
                        var attachedpro = db.attachedproduct.Where(x => x.mainproductid == selectedItem.id).ToList();
                        if (attachedpro.Count != 0)
                            foreach (var item in attachedpro)
                                db.attachedproduct.Remove(item);
                        List<Product> pr = db.product.Where(x => x.id == selectedItem.id).ToList();
                        foreach (var i in pr)
                            db.product.Remove(i);
                        db.SaveChanges();
                        LoadData();
                        Filter();
                    }
                    else MessageBox.Show("Невозможно удалить товар");
                }
            }
            else MessageBox.Show("Выберите товар, чтобы удалить его");
        }

        private void AddButton_Click(object sender, RoutedEventArgs e)
        {
            NavigationService.Navigate(new AddProductPage());
        }

        private void ChangeButton_Click(object sender, RoutedEventArgs e)
        {
            var selectedItem = ProductList.SelectedItem as ProductListClass;
            if (selectedItem != null)
                NavigationService.Navigate(new ChangeProductPage(selectedItem));
            else MessageBox.Show("Выберите товар, чтобы изменить его данные");
        }

        private void SeeButton_Click(object sender, RoutedEventArgs e)
        {
            var selectedItem = ProductList.SelectedItem as ProductListClass;
            if (selectedItem != null)
                NavigationService.Navigate(new HistoryPage(selectedItem));
            else MessageBox.Show("Выберите товар, чтобы посмотреть его историю продаж");
        }
    }
}
