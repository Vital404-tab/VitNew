﻿using Microsoft.Win32;
using System.IO;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using Work1.Class;
using Work1.DBContex;

namespace Work1.Pages
{
    /// <summary>
    /// Логика взаимодействия для AddProductPage.xaml
    /// </summary>
    public partial class AddProductPage : Page
    {

        ApplicationContext db = new ApplicationContext();
        List<ProductListClass> dopProductLists = new List<ProductListClass>();
        Image photoimage = new Image();
        string photopath;
        string file;

        public AddProductPage()
        {
            InitializeComponent();
            ManufacturerBox.ItemsSource = db.manufacturer.ToList();
            LoadData();
        }

        public void LoadData()
        {
            List<ProductListClass> productLists = new List<ProductListClass>();
            List<Product> products = db.product.ToList();
            if (dopProductLists.Count > 0)
                foreach(var i in dopProductLists)
                    products = products.Where(x=>x.id != i.id).ToList();

            foreach (var i in products)
            {
                ProductListClass productListClass = new ProductListClass();
                if (i.isactive != false)
                {
                    productListClass.id = i.id;
                    productListClass.title = i.title;
                    if (i.mainimagepath != null) productListClass.mainimagepath = $@"{Directory.GetParent(Environment.CurrentDirectory)}\products_photo\{i.mainimagepath}";
                    productListClass.cost = i.cost;
                    productLists.Add(productListClass);
                }
            }
            DopProductList.ItemsSource = productLists;
            CountDopProduct.Text = dopProductLists.Count.ToString();
        }

        private void AddProductButton_Click(object sender, RoutedEventArgs e)
        {
            if (String.IsNullOrWhiteSpace(TitleBlock.Text) || String.IsNullOrWhiteSpace(CostBlock.Text))
                MessageBox.Show("Заполните все поля");
            else if (ManufacturerBox.SelectedIndex == -1)
                MessageBox.Show("Выберите производителя");
            else if (CostBlock.Text.Contains('-') || CostBlock.Text.Contains(','))
                MessageBox.Show("Неправильный формат цены");
            else
            {
                try
                {
                    int countID = db.product.Count() + 1;
                    string nameMauf = (ManufacturerBox.SelectedItem as Manufacturer).name;
                    Product products = new Product();
                    products.id = countID;
                    products.title = TitleBlock.Text;
                    products.cost = Convert.ToDecimal(CostBlock.Text);
                    if (DescriptionBlock.Text != null) products.description = DescriptionBlock.Text;
                    if (photopath != null)
                        products.mainimagepath = $"Товары школы\\{photopath}";
                    if (ActiveBox.IsChecked == false) products.isactive = false;
                    else products.isactive = true;
                    foreach (var i in db.manufacturer.ToList())
                        if (i.name == nameMauf)
                        {
                            products.manufacturerid = i.id;
                            break;
                        }
                    db.product.Add(products);
                    db.SaveChanges();

                    if (dopProductLists.Count > 0)
                    {
                        foreach(var i in dopProductLists)
                        {
                            AttachedProduct attachedProduct = new AttachedProduct();
                            attachedProduct.mainproductid = countID;
                            attachedProduct.attachedproductid = i.id;
                            db.attachedproduct.Add(attachedProduct);
                            db.SaveChanges();
                        }
                    }


                    TitleBlock.Clear();
                    CostBlock.Clear();
                    DescriptionBlock.Clear();
                    MainImagePanel.Children.Clear();
                    ActiveBox.IsChecked = false;

                    List<Product> pr = db.product.ToList();
                    bool exist = false;
                    if (photopath != null)
                    {
                        foreach (var p in pr)
                            if (p.mainimagepath.Contains(photopath))
                                exist = true;
                    }
                    else exist = true;

                    if (exist == false)
                    {
                        string newLocation = " ";
                        string folderLocation = $@"{Directory.GetParent(Environment.CurrentDirectory)}\products_photo\Товары школы";
                        newLocation = folderLocation + "\\" + photopath;
                        File.Copy(file, newLocation, true);
                    }

                    MessageBox.Show("Вы добавили новый товар");
                }
                catch
                {
                    MessageBox.Show("Неправильный формат цены");
                }
            }
        }

        private void MainImagePanel_MouseDown(object sender, MouseButtonEventArgs e)
        {
            MainImagePanel.Children.Clear();
            OpenFileDialog openFileDialog = new OpenFileDialog();
            openFileDialog.InitialDirectory = "C:\\";
            openFileDialog.Filter = "image files (*.png)|*.png;*.jpg|All files (*.*)|*.*";
            if (openFileDialog.ShowDialog().Value)
            {
                file = openFileDialog.FileName;
                var longMB = file.Length / 1024;
                if (longMB <= 2)
                {
                    photoimage.Width = 150;
                    photoimage.Height = 150;
                    photoimage.Source = new BitmapImage(new Uri(file));
                    MainImagePanel.Children.Add(photoimage);
                    photopath = openFileDialog.SafeFileName;
                }
                else MessageBox.Show("Файл слишком большой");
            }
        }

        private void BackButton_Click(object sender, RoutedEventArgs e)
        {
            NavigationService.Navigate(new MainPage());
        }

        private void AddDopProductButton_Click(object sender, RoutedEventArgs e)
        {
            var selectedItem = DopProductList.SelectedItem as ProductListClass;
            if (selectedItem != null)
            {
                dopProductLists.Add(selectedItem);
                LoadData();
            }
            else MessageBox.Show("Выберите дополнительный товар, нажав на его элемент");
        }
    }
}
