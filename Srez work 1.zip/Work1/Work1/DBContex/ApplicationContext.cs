﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Controls;

namespace Work1.DBContex
{
    public class ApplicationContext : DbContext
    {
        public DbSet<AttachedProduct> attachedproduct { get; set; }
        public DbSet<Manufacturer> manufacturer { get; set; }
        public DbSet<Product> product { get; set; }
        public DbSet<ProductPhoto> productphoto { get; set; }
        public DbSet<ProductSale> productsale { get; set; }
        public ApplicationContext()
        {
            Database.EnsureCreated();
        }
        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            optionsBuilder.UseNpgsql("Host=localhost;Port=5432;Database=Srez1;Username=postgres;Password=123");
        }
    }
}
