﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Work1.DBContex
{
    public class Product
    {
        public int id { get; set; }
        public string title { get; set; }
        public decimal cost { get; set; }
        public string? description { get; set; }
        public string? mainimagepath { get; set; }
        public bool isactive { get; set; }
        public int? manufacturerid { get; set; }
    }
}
