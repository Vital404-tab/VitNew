﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Work1.Class
{
    public class ProductListClass
    {
        public int id { get; set; }
        public string title { get; set; }
        public string countDopProduct { get; set; }
        public decimal cost { get; set; }
        public string description { get; set; }
        public string? mainimagepath { get; set; }
        public string? isactive { get; set; }
        public string? manufacturerid { get; set; }
        public string colorBack { get; set; }
        public DateTime saledate { get; set; }
        public int quantity { get; set; }
    }
}
