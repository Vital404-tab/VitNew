﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Work1.DBContex
{
    public class ProductSale
    {
        public int id { get; set; }
        public DateTime saledate { get; set; }
        public int productid { get; set; }
        public int quantity { get; set; }
    }
}
